package br.com.transporte;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApitransportadoraApplicationTests {

	@Test
	void contextLoads() {
	}

}
