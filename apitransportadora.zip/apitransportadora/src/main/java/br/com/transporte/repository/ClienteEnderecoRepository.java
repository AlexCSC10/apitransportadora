package br.com.transporte.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import br.com.transporte.pojo.Endereco;

public interface ClienteEnderecoRepository extends JpaRepository<Endereco, Long> {

}
