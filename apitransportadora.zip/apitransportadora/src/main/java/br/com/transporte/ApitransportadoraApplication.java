package br.com.transporte;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApitransportadoraApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApitransportadoraApplication.class, args);
	}

}
