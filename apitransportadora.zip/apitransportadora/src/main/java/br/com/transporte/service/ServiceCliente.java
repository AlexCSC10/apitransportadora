package br.com.transporte.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import br.com.transporte.pojo.Cliente;
import br.com.transporte.repository.ClienteEnderecoRepository;
import br.com.transporte.repository.ClienteRepository;

@Service
public class ServiceCliente {
	@Autowired
	ClienteRepository clienteRepository;
	@Autowired
	ClienteEnderecoRepository clienteEnderecoRepository;

	/**
	 * Faz o cadastro do cliente no banco de dadosS
	 * 
	 * @param cliente
	 * @return
	 */
	public ResponseEntity<?> inserirCliente(Cliente cliente) {
		clienteRepository.save(cliente);
		return ResponseEntity.status(201).body(cliente);
	}

	/**
	 * Altera o cliente no banco de dados
	 * 
	 * @param cliente
	 * @return
	 */
	public ResponseEntity<?> alterarCliente(Cliente cliente) {
		Optional<Cliente> clienteData = clienteRepository.findById(cliente.getId_cliente());
		if (clienteData.isPresent()) {
			Cliente _cliente = clienteData.get();
			_cliente.setCnpj(cliente.getCnpj());
			_cliente.setCpf(cliente.getCpf());
			_cliente.setEmail(cliente.getEmail());
			_cliente.setNome(cliente.getNome());
			_cliente.setRedeSocial(cliente.getRedeSocial());
			_cliente.setRg(cliente.getRg());
			_cliente.setSexo(cliente.getSexo());
			_cliente.setTelefone(cliente.getTelefone());
			_cliente.setEnderecos(cliente.getEnderecos());
			return ResponseEntity.ok(clienteRepository.save(_cliente));
		} else
			return ResponseEntity.notFound().build();
	}

	/**
	 * Lista todos os clientes
	 * 
	 * @return
	 */
	public ResponseEntity<?> listarClientes() {
		List<Cliente> clientes = clienteRepository.findAll();
		if (clientes != null && !clientes.isEmpty())
			return ResponseEntity.ok(clientes);
		else
			return ResponseEntity.noContent().build();
	}

	/**
	 * Busca os clientes por ID
	 * 
	 * @param id_cliente
	 * @return
	 */
	public ResponseEntity<?> listarClientesPorId(long id_cliente) {
		Optional<Cliente> clienteData = clienteRepository.findById(id_cliente);
		if (clienteData.isPresent())
			return ResponseEntity.ok(clienteData);
		else
			return ResponseEntity.notFound().build();
	}

	/**
	 * Deleta o cliente do banco de dados
	 * 
	 * @param id_cliente
	 * @return
	 */
	public ResponseEntity<?> deletarCliente(long id_cliente) {
		Optional<Cliente> clienteData = clienteRepository.findById(id_cliente);
		if (clienteData.isPresent()) {
			clienteRepository.deleteById(id_cliente);
			return ResponseEntity.noContent().build();
		} else
			return ResponseEntity.notFound().build();
	}

}
