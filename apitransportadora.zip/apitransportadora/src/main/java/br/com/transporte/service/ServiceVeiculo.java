package br.com.transporte.service;

import java.util.List;

import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import br.com.transporte.pojo.Veiculo;
import br.com.transporte.repository.VeiculoRepository;

@Service
public class ServiceVeiculo {
	@Autowired
	VeiculoRepository veiculoRepository;

	/**
	 * Cadastra o Veiculo na base de dados
	 * 
	 * @param veiculo
	 * @return
	 */
	public ResponseEntity<?> inserirVeiculo(Veiculo veiculo) {
		veiculoRepository.save(veiculo);
		return ResponseEntity.status(201).body(veiculo);
	}

	/**
	 * Pesquisa e Altera o Veiculo da Base de dados
	 * 
	 * @param veiculo
	 * @return
	 */
	public ResponseEntity<?> alterarVeiculo(@Valid Veiculo veiculo) {
		Optional<Veiculo> veiculoData = veiculoRepository.findById(veiculo.getId_veiculo());

		if (veiculoData.isPresent()) {
			Veiculo _veiculo = veiculoData.get();
			_veiculo.setCapacidade(veiculo.getCapacidade());
			_veiculo.setKml(veiculo.getKml());
			_veiculo.setMarca(veiculo.getMarca());
			_veiculo.setMultas(veiculo.getMultas());
			_veiculo.setPessoas(veiculo.getPessoas());
			_veiculo.setPlaca(veiculo.getPlaca());
			_veiculo.setRastreamento(veiculo.getRastreamento());
			_veiculo.setRenavam(veiculo.getRenavam());
			_veiculo.setSeguradora(veiculo.getSeguradora());
			return ResponseEntity.ok(veiculoRepository.save(_veiculo));
		} else
			return ResponseEntity.notFound().build();

	}

	/**
	 * Lista todos os veiculos cadastrados na base de dados
	 * 
	 * @return
	 */
	public ResponseEntity<?> listarVeiculos() {
		List<Veiculo> veiculos = veiculoRepository.findAll();
		if (veiculos != null && !veiculos.isEmpty())
			return ResponseEntity.ok(veiculos);
		else
			return ResponseEntity.noContent().build();
	}

	/**
	 * Pesquisa veiculos por ID
	 * 
	 * @param id_veiculo
	 * @return
	 */
	public ResponseEntity<?> listarVeiculosPorId(long id_veiculo) {
		Optional<Veiculo> veiculoData = veiculoRepository.findById(id_veiculo);
		if (veiculoData.isPresent())
			return ResponseEntity.ok(veiculoData);
		else
			return ResponseEntity.notFound().build();

	}

	/**
	 * Pesquisa e exclui o veiculo da base de dados
	 * 
	 * @param id_veiculo
	 * @return
	 */
	public ResponseEntity<?> deletarVeiculo(long id_veiculo) {
		Optional<Veiculo> veiculoData = veiculoRepository.findById(id_veiculo);
		if (veiculoData.isPresent()) {
			veiculoRepository.deleteById(id_veiculo);
			return ResponseEntity.noContent().build();
		} else
			return ResponseEntity.notFound().build();
	}

}
