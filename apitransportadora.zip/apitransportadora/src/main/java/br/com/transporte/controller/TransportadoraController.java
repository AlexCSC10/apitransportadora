package br.com.transporte.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import br.com.transporte.pojo.Cliente;
import br.com.transporte.pojo.Veiculo;
import br.com.transporte.service.ServiceCliente;
import br.com.transporte.service.ServiceVeiculo;

@RestController
@RequestMapping("transportadora/v1")
public class TransportadoraController {

	@Autowired
	ServiceVeiculo serviceVeiculo;
	@Autowired
	ServiceCliente serviceCliente;

	@PostMapping("/veiculos")
	public ResponseEntity<?> inserirVeiculo(@RequestBody Veiculo veiculo) {
		return serviceVeiculo.inserirVeiculo(veiculo);
	}

	@PutMapping("/veiculos")
	public ResponseEntity<?> alterarVeiculo(@RequestBody Veiculo veiculo) {
		return serviceVeiculo.alterarVeiculo(veiculo);
	}

	@GetMapping("/veiculos")
	public ResponseEntity<?> listarVeiculos() {
		return serviceVeiculo.listarVeiculos();
	}

	@GetMapping("/veiculos/identificador/{id_veiculo}")
	public ResponseEntity<?> pesquisarVeiculosPorId(@PathVariable("id_veiculo") long id_veiculo) {
		return serviceVeiculo.listarVeiculosPorId(id_veiculo);
	}

	@DeleteMapping("/veiculos/identificador/{id_veiculo}")
	public ResponseEntity<?> deletarVeiculo(@PathVariable("id_veiculo") long id_veiculo) {
		return serviceVeiculo.deletarVeiculo(id_veiculo);
	}

	@PostMapping("/clientes")
	public ResponseEntity<?> inserirCliente(@RequestBody Cliente cliente) {
		return serviceCliente.inserirCliente(cliente);
	}

	@PutMapping("/clientes")
	public ResponseEntity<?> alterarCliente(@RequestBody Cliente cliente) {
		return serviceCliente.alterarCliente(cliente);
	}

	@GetMapping("/clientes")
	public ResponseEntity<?> listarCliente() {
		return serviceCliente.listarClientes();
	}

	@GetMapping("/clientes/identificador/{id_cliente}")
	public ResponseEntity<?> pesquisarClientesPorId(@PathVariable("id_cliente") long id_cliente) {
		return serviceCliente.listarClientesPorId(id_cliente);
	}

	@DeleteMapping("/clientes/identificador/{id_cliente}")
	public ResponseEntity<?> deletarCliente(@PathVariable("id_cliente") long id_cliente) {
		return serviceCliente.deletarCliente(id_cliente);
	}

}
